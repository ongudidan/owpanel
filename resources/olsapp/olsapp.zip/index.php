<?php
define('olsapp', true);
require_once "conf.php";

require_once "".$globals['path']."/core/autoload.php";

$core->LoadOlsApp();


?>