<?php



if(!defined('olsapp')){

	die('Unwanted Attempt');

}

$globals['path'] = '/usr/local/lsws/Example/html/olsapp';
$globals['scripts'] = '/usr/local/lsws/Example/html/olsapp/apps';
$globals['sn'] = 'olsapp';
$globals['cookie_name'] = 'olsappCookies17';
$globals['gzip'] = 1;
$globals['language'] = 'english';
$globals['soft_email'] = 'hostbdfree@gmail.com';
$globals['from_email'] = NULL;
$globals['theme_folder'] = 'default';
$globals['timezone'] = 0;
$globals['mail'] = 1;
$globals['off'] = 0;
$globals['off_subject'] = '';
$globals['off_message'] = '';
$globals['update'] = 1;
$globals['email_update'] = 1;
$globals['email_update_softs'] = 1;


