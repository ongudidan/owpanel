
<div class="dashboard-wrapper">
  <div class="container-fluid dashboard-content">
    <div class="row justify-content-center mt-5">
      <div class="col-md-8 text-center">
        <h1 class="display-1 text-danger">404</h1>
        <h3 class="mb-3">Page Not Found</h3>
        <p class="text-muted">Sorry, the page you’re looking for doesn’t exist or has been moved.</p>
        <a href="/" class="btn btn-primary mt-3">Go to Homepage</a>
      </div>
    </div>
  </div>
</div>

       