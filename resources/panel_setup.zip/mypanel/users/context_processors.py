import requests
from .plugin import * 



def dynamic_plugins(request):
    """Make plugin lists available globally (e.g., sidebar)"""
    # Optional parameter example (softaculous)
    softaculous = True

    return {
        'software_plugin': get_software_plugins_list(softaculous),
        'domain_plugin': get_domain_plugins_list(),
        'file_plugin': get_file_plugins_list(),
        'security_plugin': get_security_plugins_list(),
        'database_plugin': get_database_plugins_list(),
        'email_plugin': get_email_plugins_list(),
        'advance_plugin': get_advance_plugins_list(),
    }
