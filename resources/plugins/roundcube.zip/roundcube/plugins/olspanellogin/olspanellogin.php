<?php

/**
 * OLSPanel Roundcube Auto-Login Plugin
 * Authenticates user based on PHP session data set before accessing Roundcube.
 */
class olspanellogin extends rcube_plugin
{
	 public $task = 'login';

  function init()
  { 
	 if (isset($_GET['_task']) && $_GET['_task'] === 'login' && empty($_POST['_user'])) {

		 $rcmail = rcmail::get_instance();
            $rcmail->logout_actions();
            $rcmail->kill_session();
        }
		
    $this->add_hook('startup', array($this, 'startup'));
	

    $this->add_hook('authenticate', array($this, 'authenticate'));
	 
  } 

  function startup($args)
  {
    $rcmail = rcmail::get_instance();
	
    if (empty($_SESSION['user_id']) )
      $args['action'] = 'login';
    return $args;
  }

  function authenticate($args)
  {
	 if(empty($_POST['_user'])){
    $args['user'] = $_SERVER['HTTP_AUTOLOGINUSER'];
    $args['pass'] = $_SERVER['HTTP_AUTOLOGINPASS'];
	 
    $args['host'] = 'localhost';
	
	 }
	 
    return $args;
  }
}
	


?>
