# header.pl

sub print_header {
    my ($result_msg, $bootstrapcss, $jqueryjs, $bootstrapjs, $images) = @_;

    print <<"END_HTML";
<!doctype html>
<html lang='en'>
<head>
    <title>ConfigServer Security &amp; Firewall</title>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    $bootstrapcss
    <link href='$images/configserver.css' rel='stylesheet' type='text/css'>
    $jqueryjs
    $bootstrapjs
</head>
<body>
<div id="loader" style="display: none;"></div>
<a id="toplink" class="toplink" title="Go to bottom" style="display: none;">
    <span class="glyphicon glyphicon-hand-down"></span>
</a>
<div class="container-fluid">
<br>
<div class="panel panel-default">
    <h4><img src="$images/csf_small.png" style="padding-left: 10px"> Firewall with UFW Management</h4>
</div>
END_HTML

    if ($result_msg) {
       # print "<div class='bs-callout bs-callout-success text-center'>$result_msg</div>";
    }

   

    
   

    
}
1;