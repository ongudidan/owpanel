sub print_logs {
    my ($options_html) = @_;  # pass only options HTML for clarity

    print <<"HTML";
<div class="container-fluid">

 
	

<div>
 <select id="CSFlognum" name="lognum" onchange="CSFrefreshtimer()">
    $options_html
  </select>
 Lines:<input type="text" id="CSFlines" value="100" size="4">&nbsp;&nbsp;<button class="btn btn-default" onclick="CSFrefreshtimer()">Refresh Now</button></div>
<div>Refresh in <span id="CSFtimer">4</span> <button class="btn btn-default" id="CSFpauseID" onclick="CSFpausetimer()" style="width:80px;">Pause</button> <img src="/media/csf/loader.gif" id="CSFrefreshing" style="display: none;"></div>
<div class="pull-right btn-group"><button class="btn btn-default" id="fontminus-btn"><strong>a</strong><span class="glyphicon glyphicon-arrow-down icon-configserver"></span></button>
<button class="btn btn-default" id="fontplus-btn"><strong>A</strong><span class="glyphicon glyphicon-arrow-up icon-configserver"></span></button></div>
<pre class="comment" id="CSFajax" style="overflow:auto;height:500px;resize:both; white-space: pre-wrap;clear:both">&lt;---- /usr/local/lsws/logs/access.log is currently empty ----&gt;</pre>


<hr>
<div>
<button class="btn btn-default" onclick="window.history.back();">Return</button>

</div>


HTML

 print <<'HTML';
<script>

var CSFscript = '';
var CSFcountval = 6;
var CSFlineval = 100;
var CSFcounter;
var CSFcount = 1;
var CSFpause = 0;
var CSFfrombot = 120;
var CSFfromright = 10;
var CSFsettimer = 0;
var CSFheight = 0;
var CSFwidth = 0;
var CSFajaxHTTP = CSFcreateRequestObject();

function CSFcreateRequestObject() {
	var CSFajaxRequest;
	if (window.XMLHttpRequest) {
		CSFajaxRequest = new XMLHttpRequest();
	}
	else if (window.ActiveXObject) {
		CSFajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
	}
	else {
		alert('There was a problem creating the XMLHttpRequest object in your browser');
		CSFajaxRequest = '';
	}
	return CSFajaxRequest;
}

function CSFsendRequest(url) {
	var now = new Date();
	CSFajaxHTTP.open('get', url + '&nocache=' + now.getTime());
	CSFajaxHTTP.onreadystatechange = CSFhandleResponse;
	CSFajaxHTTP.send();
	document.getElementById("CSFrefreshing").style.display = "inline";
} 

function CSFhandleResponse() {
	if(CSFajaxHTTP.readyState == 4 && CSFajaxHTTP.status == 200){
		if(CSFajaxHTTP.responseText) {
			var CSFobj = document.getElementById("CSFajax");
			CSFobj.innerHTML = CSFajaxHTTP.responseText;
			waitForElement("CSFajax",function(){
				CSFobj.scrollTop = CSFobj.scrollHeight;
			});
			document.getElementById("CSFrefreshing").style.display = "none";
			if (CSFsettimer) {CSFcounter = setInterval(CSFtimer, 1000);}
		}
	}
}

function waitForElement(elementId, callBack){
	window.setTimeout(function(){
		var element = document.getElementById(elementId);
		if(element){
			callBack(elementId, element);
		}else{
			waitForElement(elementId, callBack);
		}
	},500)
}

function CSFgrep() {
	CSFsettimer = 0;
	var CSFlogobj = document.getElementById("CSFlognum");
	var CSFlognum;
	if (CSFlogobj) {CSFlognum = '&lognum=' + CSFlogobj.options[CSFlogobj.selectedIndex].value}
	else {CSFlognum = ""}
	if (document.getElementById("CSFgrep_i").checked) {CSFlognum = CSFlognum + "&grepi=1"}
	if (document.getElementById("CSFgrep_E").checked) {CSFlognum = CSFlognum + "&grepE=1"}
	if (document.getElementById("CSFgrep_Z").checked) {CSFlognum = CSFlognum + "&grepZ=1"}
	var CSFurl = CSFscript + '&grep=' + document.getElementById("CSFgrep").value + CSFlognum;
	CSFsendRequest(CSFurl);
}

function CSFtimer() {
	CSFsettimer = 1;
	if (CSFpause) {return}
	CSFcount = CSFcount - 1;
	document.getElementById("CSFtimer").innerHTML = CSFcount;
	if (CSFcount <= 0) {
		clearInterval(CSFcounter);
		var CSFlogobj = document.getElementById("CSFlognum");
		var CSFlognum;
		if (CSFlogobj) {CSFlognum = '&lognum=' + CSFlogobj.options[CSFlogobj.selectedIndex].value}
		else {CSFlognum = ""}
		CSFsendRequest(CSFscript + '&lines=' + document.getElementById("CSFlines").value + CSFlognum);
		CSFcount = CSFcountval;
		return;
	}
}

function CSFpausetimer() {
	if (CSFpause) {
		CSFpause = 0;
		document.getElementById("CSFpauseID").innerHTML = "Pause";
	}
	else {
		CSFpause = 1;
		document.getElementById("CSFpauseID").innerHTML = "Continue";
	}
}

function CSFrefreshtimer() {
	var pause = CSFpause;
	CSFcount = 1;
	CSFpause = 0;
	CSFtimer();
	CSFpause = pause;
	CSFcount = CSFcountval - 1;
	document.getElementById("CSFtimer").innerHTML = CSFcount;
}

function windowSize() {
	if( typeof( window.innerHeight ) == 'number' ) {
		CSFheight = window.innerHeight;
		CSFwidth = window.innerWidth;
	}
	else if (document.documentElement && (document.documentElement.clientHeight)) {
		CSFheight = document.documentElement.clientHeight;
		CSFwidth = document.documentElement.clientWidth;
	}
	else if (document.body && (document.body.clientHeight)) {
		CSFheight = document.body.clientHeight;
		CSFwidth = document.body.clientWidth;
	}
}


CSFfrombot = 120;
	CSFfromright = 10;
	CSFscript = '/whm/iframe/?action=logtailcmd';
	CSFtimer();

	var myFont = 14;
	$("#fontplus-btn").on('click', function () {
		myFont++;
		if (myFont > 20) {myFont = 20}
		$('#CSFajax').css("font-size",myFont+"px");
	});
	$("#fontminus-btn").on('click', function () {
		myFont--;
		if (myFont < 12) {myFont = 12}
		$('#CSFajax').css("font-size",myFont+"px");
	});
</script>



HTML
}
1;