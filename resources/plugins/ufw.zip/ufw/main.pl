# main.pl

sub print_main {
    my () = @_;

 my $ufw_status = get_ufw_status();   

if ($ufw_status eq 'active') {
        print <<'HTML';
<div class="bs-callout bs-callout-success text-center">
    <h4>Firewall Status: Enabled and Running</h4>
</div>
HTML
    } else {
        print <<'HTML';
<div class="bs-callout bs-callout-danger text-center">
<form action="" method="post">
    <h4>Firewall Status: Disabled and Stopped
        <input type="hidden" name="action" value="ufw_enable">
        <input type="submit" class="btn btn-default" value="Enable">
    </h4>
</form>
</div>
HTML
    }
	
print <<"END_HTML";	
<div class="normalcontainer">
<ul class="nav nav-tabs" id="myTabs" style="font-weight:bold">
<li class="active"><a data-toggle="tab" href="#ufw">UFW Management</a></li>
<li><a data-toggle="tab" href="#auto_block">Brute force protection</a></li>
<li><a data-toggle="tab" href="#other">others</a></li>
</ul>

<div class="tab-content">

<!-- UFW Management Tab -->
<div id="ufw" class="tab-pane active">
<div class="ufw-section">
<h3>UFW Status and Control</h3>
<table class="table table-bordered table-striped">
<thead><tr><th colspan="2">UFW - Uncomplicated Firewall Management</th></tr></thead>
<tbody>
<tr><td><form action="" method="post"><button name="action" value="logtail" type="submit" class="btn btn-info">Watch System Logs</button></form></td><td style="width:100%">Display current UFW firewall status and configuration</td></tr>
<tr><td><form action="" method="post"><button name="action" value="ufw_enable" type="submit" class="btn btn-success">Enable UFW</button></form></td><td style="width:100%">Enable UFW firewall protection</td></tr>
<tr><td><form action="" method="post"><button name="action" value="ufw_disable" type="submit" class="btn btn-warning">Disable UFW</button></form></td><td style="width:100%">Disable UFW firewall (WARNING: This will remove firewall protection)</td></tr>
<tr><td><form action="" method="post"><button name="action" value="ufw_restart" type="submit" class="btn btn-danger">Restart UFW</button></form></td><td style="width:100%">Restart UFW </td></tr>
<tr><td><form action="" method="post"><button name="action" value="ufw_list_rules_table" type="submit" class="btn btn-default">List All Rules as table</button></form></td><td style="width:100%">Display all current UFW rules  as table with delete option</td></tr>

<tr><td><form action="" method="post"><button name="action" value="ufw_list_rules" type="submit" class="btn btn-default">List All Rules as plain</button></form></td><td style="width:100%">Display all current UFW rules with rule numbers</td></tr>
</tbody>
</table>
</div>

<div class="ufw-section">
<h3>IP Address Management</h3>
<table class="table table-bordered table-striped">
<thead><tr><th colspan="2">UFW IP Address Rules</th></tr></thead>
<tbody>
<tr><td><button onclick="\$('#ufw_allow_ip_form').submit();" class="btn btn-success">Allow IP</button></td><td style="width:100%">
<form action="" method="post" id="ufw_allow_ip_form" class="ufw-form">
<input type="hidden" name="action" value="ufw_allow_ip">
Allow IP address: <input type="text" name="ip" placeholder="" class="ufw-input" style="background-color: #BDECB6" required>
<br>Comment: <input type="text" name="comment" placeholder="Optional comment" class="ufw-input">
</form>
</td></tr>
<tr><td><button onclick="\$('#ufw_deny_ip_form').submit();" class="btn btn-danger">Deny IP</button></td><td style="width:100%">
<form action="" method="post" id="ufw_deny_ip_form" class="ufw-form">
<input type="hidden" name="action" value="ufw_deny_ip">
Deny IP address: <input type="text" name="ip" placeholder="" class="ufw-input" style="background-color: #FFD1DC" required>
<br>Comment: <input type="text" name="comment" placeholder="Optional comment" class="ufw-input">
</form>
</td></tr>
</tbody>
</table>
</div>

<div class="ufw-section">
<h3>Port Management</h3>
<table class="table table-bordered table-striped">
<thead><tr><th colspan="2">UFW Port Rules</th></tr></thead>
<tbody>
<tr><td><button onclick="\$('#ufw_allow_port_form').submit();" class="btn btn-success">Allow Port</button></td><td style="width:100%">
<form action="" method="post" id="ufw_allow_port_form" class="ufw-form">
<input type="hidden" name="action" value="ufw_allow_port">
Port: <input type="text" name="port" placeholder="80" class="ufw-input" style="background-color: #BDECB6" required>
Protocol: <select name="protocol" class="ufw-input">
<option value="tcp">TCP</option>
<option value="udp">UDP</option>
</select>
<div class="port-quick-fill">
<small>Quick fill: </small>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '80')">HTTP</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '443')">HTTPS</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '22')">SSH</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '21')">FTP</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '25')">SMTP</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '53')">DNS</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '3306')">MySQL</button>
</div>
</form>
</td></tr>
<tr><td><button onclick="\$('#ufw_deny_port_form').submit();" class="btn btn-danger">Deny Port</button></td><td style="width:100%">
<form action="" method="post" id="ufw_deny_port_form" class="ufw-form">
<input type="hidden" name="action" value="ufw_deny_port">
Port: <input type="text" name="port" placeholder="22" class="ufw-input" style="background-color: #FFD1DC" required>
Protocol: <select name="protocol" class="ufw-input">
<option value="tcp">TCP</option>
<option value="udp">UDP</option>
</select>
<div class="port-quick-fill">
<small>Quick fill: </small>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '80')">HTTP</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '443')">HTTPS</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '22')">SSH</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '21')">FTP</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '25')">SMTP</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '53')">DNS</button>
<button type="button" class="btn btn-xs btn-default" onclick="fillPort('port', '3306')">MySQL</button>
</div>
</form>
</td></tr>
</tbody>
</table>
</div>

<div class="ufw-section">
<h3>Search and Rule Management</h3>
<table class="table table-bordered table-striped">
<thead><tr><th colspan="2">UFW Search and Rule Operations</th></tr></thead>
<tbody>
<tr><td><button onclick="\$('#ufw_search_form').submit();" class="btn btn-info">Search Rules</button></td><td style="width:100%">
<form action="" method="post" id="ufw_search_form" class="ufw-form">
<input type="hidden" name="action" value="ufw_search">
Search for IP/Port: <input type="text" name="search_term" placeholder="" class="ufw-input" style="background-color: #D9EDF7" required>
</form>
</td></tr>
<tr><td><button onclick="\$('#ufw_remove_rule_form').submit();" class="btn btn-warning">Remove Rule</button></td><td style="width:100%">
<form action="" method="post" id="ufw_remove_rule_form" class="ufw-form">
<input type="hidden" name="action" value="ufw_remove_rule">
Rule Number: <input type="text" name="rule_number" placeholder="1" class="ufw-input" style="background-color: #FCF8E3" required>
<br><small>Use "List All Rules" to see rule numbers</small>
</form>
</td></tr>
</tbody>
</table>
</div>
</div>




<div id="other" class="tab-pane">
<table class="table table-bordered table-striped">
<thead><tr><th colspan="2">Other</th></tr></thead><tbody><tr><td><form action="" method="post"><button name="action" value="logtail" type="submit" class="btn btn-default">View Log</button></form></td><td style="width:100%">View all log</td></tr>
</tbody></table>
</div>



<div id="auto_block" class="tab-pane">
<h3>Auto-ban IP address after multiple failed login attempts.</h3>

END_HTML
 conf_list_head();
  print <<"END_HTML";
    <div class="tab-content">
END_HTML

    conf_list();

    print <<"END_HTML";


</div>
</div>



</div>
</div>
<script> window.fillIP = function(fieldName, ip) {
        \$('input[name="' + fieldName + '"]').val(ip).trigger('input');
    };
    
    window.fillPort = function(fieldName, port) {
        \$('input[name="' + fieldName + '"]').val(port).trigger('input');
    };
    </script>
END_HTML
}
1;

