sub print_msg {
    my ($msg) = @_;  # pass only options HTML for clarity

    print <<"HTML";
<div class="container-fluid">

 
	

<div>



<pre class="comment" id="CSFajax" style="overflow:auto;height:500px;resize:both; white-space: pre-wrap;clear:both">$msg</pre>


<hr>
<div>
<button class="btn btn-default" onclick="window.history.back();">Return</button>

</div>


HTML

 
}
1;