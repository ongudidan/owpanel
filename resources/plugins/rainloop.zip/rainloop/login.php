<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>RainLoop Auto Login</title>
<style>
  #loading {
    display: none;
    font-family: monospace;
    font-weight: bold;
    color: #007BFF;
    margin-top: 20px;
  }
</style>
</head>
<body>

<div id="loading">Logging in, please wait...</div>

<script>
function params(inputs) {
  let param = [], index;
  for (index in inputs) {
    param.push(`${encodeURIComponent(index)}=${encodeURIComponent(inputs[index])}`);
  }
  return param.join('&');
}

async function doLoginAndRedirect() {
  const loadingDiv = document.getElementById('loading');
  loadingDiv.style.display = 'block';  // show loading

  const email = '<?=$_SERVER['HTTP_AUTOLOGINUSER'];?>';
    
  const password = '<?=$_SERVER['HTTP_AUTOLOGINPASS'];?>';

  try {
    const response = await fetch(getUrlParent()+'?ExternalLogin', {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: params({
        Email: email,
        Password: password,
        Output: 'json'
      }),
      credentials: 'include'
    });

    // optionally check response here

  } catch (err) {
    // optionally handle error
  }

  // redirect after login attempt
  redirectToParent();
}

function isPhpFile(filename) {
  return /\.php$/i.test(filename); // check if ends with .php (case-insensitive)
}

function redirectToParent() {
  const urlObj = new URL(window.location.href);

  // Remove query string
  urlObj.search = '';

  // Split path, filter empty parts
  const parts = urlObj.pathname.split('/').filter(p => p);

  // Remove last if it is a .php file
  if (parts.length > 0 && isPhpFile(parts[parts.length - 1])) {
    parts.pop();
  }

  // Rebuild pathname with trailing slash if not empty
  urlObj.pathname = '/' + parts.join('/') + (parts.length ? '/' : '');

  window.location.href = urlObj.toString();
}

function getUrlParent() {
  const urlObj = new URL(window.location.href);

  // Remove query string
  urlObj.search = '';

  const parts = urlObj.pathname.split('/').filter(p => p);

  if (parts.length > 0 && isPhpFile(parts[parts.length - 1])) {
    parts.pop();
  }

  urlObj.pathname = '/' + parts.join('/') + (parts.length ? '/' : '');

  return urlObj.toString();
}

// Run on page load
window.onload = () => {
  doLoginAndRedirect();
};
</script>

</body>
</html>
